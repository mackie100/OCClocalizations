OpencoreBuilder="Opencore Building"

prompt1="Para instalar"
prompt2="primero debe introducir la contraseña de su cuenta de administrador:"

Cancel="Cancelar"

Continue="Continuar"

User_aborted="Operación interrumpida por el usuario"

Building="Construyendo"

Missing_package="Falta directorio de paquetes"

Invalid_version="Versión inválida"

Copying_OpenDuetPkg="Copiando archivo de arranque OpenDuetPkg desde"

Failed_OpenDuetPkg="Error al encontrar OpenDuetPkg en"

Downloading_AUDK="Descargando el repositorio OcBinaryData AUDK..."

Downloading_OpenCorePkg="Descargando el repositorio OpenCorePkg..."

Downloading_OcBinaryData="Descargando el repositorio OcBinaryData..."

Generating_EFI="Generando estructura de carpetas del EFI..."

Building_complete="El proceso de construcción ha finalizado"

Copying_Binary="Copiando datos binarios..."

install_NASM="Antes de empezar a compilar OpenCorePkg, es necesario instalar NASM"

install_MTOC="Antes de empezar a compilar OpenCorePkg, es necesario instalar MTOC"

Applied_patch="Parche aplicado"

Compiling_OpenCorePkg="Compilando la última versión de OpenCorePkg..."

Downloading_mod="Descargando el parche Mod..."

Applying_patch="Aplicando parche..."

No_mod_patch="No se ha encontrado ningún parche mod. Parche no aplicado!"
