OpencoreBuilder="Opencore正在编译"

prompt1="要安装"
prompt2="首先,您需要在下面输入管理员帐户密码才能继续:"

Cancel="取消"

Continue="继续"

User_aborted="用户中止操作"

Building="正在构建"

Missing_package="缺少包目录"

Invalid_version="版本无效"

Copying_OpenDuetPkg="从复制OpenDuetPkg启动文件"

Failed_OpenDuetPkg="在找不到OpenDuetPkg"

Downloading_AUDK="下载AUDK资料库..."

Downloading_OpenCorePkg="下载OpenCorePkg存储库..."

Downloading_OcBinaryData="下载OcBinaryData存储库..."

Generating_EFI="生成EFI文件夹结构..."

Building_complete="构建过程完成"

Copying_Binary="复制二进制数据..."

install_NASM="在开始构建OpenCorePkg之前,需要安装NASM"

install_MTOC="在开始构建OpenCorePkg之前,需要安装MTOC"

Applied_patch="应用补丁"

Compiling_OpenCorePkg="编译最新提交的OpenCorePkg版本..."

Downloading_mod="正在下载 Mod 补丁..."

Applying_patch="应用补丁..."

No_mod_patch="没有找到mod补丁. 未应用补丁!"
