OpencoreBuilder="Opencore Building"

prompt1="To install"
prompt2="first you need to enter your administrator account password below to continue:"

Cancel="Cancel"

Continue="Continue"

User_aborted="Operation aborted by user"

Building="Building"

Missing_package="Missing package directory"

Invalid_version="Invalid version"

Copying_OpenDuetPkg="Copying OpenDuetPkg boot file from"

Failed_OpenDuetPkg="Failed to find OpenDuetPkg at"

Downloading_AUDK="Downloading AUDK repository..."

Downloading_OpenCorePkg="Downloading OpenCorePkg repository..."

Downloading_OcBinaryData="Downloading OcBinaryData repository..."

Generating_EFI="Generating EFI Structure folder..."

Building_complete="Building process is completed"

Copying_Binary="Copying Binary Data..."

install_NASM="Before starting to build OpenCorePkg, I need to install NASM"

install_MTOC="Before starting to build OpenCorePkg, I need to install MTOC"

Applied_patch="Applied patch"

Compiling_OpenCorePkg="Compiling the latest commited version of OpenCorePkg..."

Downloading_mod="Downloading Mod patch..."

Applying_patch="Applying patch..."

No_mod_patch="No mod patch found. Patch not applied!"
